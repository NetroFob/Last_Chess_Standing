extends CharacterBody2D

@export var tile_map_layer: TileMapLayer
@export var speed: float = 150.0

var target_position: Vector2 = Vector2.ZERO
var target_cell: Vector2i = Vector2i.ZERO
var is_moving: bool = false

func _ready():
	target_position = global_position
	if tile_map_layer == null:
		push_error("❌ TileMapLayer не назначен!")

func _input(event):
	if tile_map_layer == null or is_moving:
		return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		var local_mouse = tile_map_layer.to_local(get_global_mouse_position())
		var clicked_cell = tile_map_layer.local_to_map(local_mouse)
		var start_cell = tile_map_layer.local_to_map(to_local(global_position))

		# 🔍 ПРОВЕРКА ПУТИ "БУКВОЙ Г" ПЕРЕД ЗАПУСКОМ
		if _validate_l_path(start_cell, clicked_cell):
			target_cell = clicked_cell
			target_position = tile_map_layer.to_global(tile_map_layer.map_to_local(clicked_cell))
			is_moving = true
			print("✅ Путь валиден. Движение к: ", clicked_cell)
		else:
			print("⚠️ Путь заблокирован пустыми клетками. Движение отменено.")

func _validate_l_path(start: Vector2i, end: Vector2i) -> bool:
	# 🔹 Проверяем горизонтальный отрезок
	var x = start.x
	while x != end.x:
		if not _is_tile_valid(Vector2i(x, start.y)): return false
		x += sign(end.x - start.x)
		
	# Проверяем угловую клетку (поворот)
	if not _is_tile_valid(Vector2i(end.x, start.y)): return false
	
	# 🔹 Проверяем вертикальный отрезок
	var y = start.y
	while y != end.y:
		if not _is_tile_valid(Vector2i(end.x, y)): return false
		y += sign(end.y - start.y)
		
	return true

# Универсальная проверка клетки (совместима с Godot 4.2+)
func _is_tile_valid(pos: Vector2i) -> bool:
	var cell_data = tile_map_layer.get_cell_at(pos)
	return cell_data != null and cell_data != -1

func _physics_process(delta):
	if not is_moving:
		velocity = Vector2.ZERO
		return

	var move_dir = Vector2.ZERO
	var dist_x = abs(target_position.x - global_position.x)
	var dist_y = abs(target_position.y - global_position.y)

	# 🔧 ЛОГИКА "Г": Сначала выравниваемся по X, только потом по Y
	if dist_x > 2.0:
		move_dir.x = sign(target_position.x - global_position.x)
	elif dist_y > 2.0:
		move_dir.y = sign(target_position.y - global_position.y)
		global_position.x = target_position.x # 🔒 Жёсткая фиксация X перед вертикалью

	if move_dir != Vector2.ZERO:
		velocity = move_dir * speed
		move_and_slide()
	else:
		# Цель достигнута
		global_position = target_position
		velocity = Vector2.ZERO
		is_moving = false
