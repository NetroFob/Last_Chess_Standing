extends CharacterBody2D

@export var speed: float = 400.0
@export var tile_map_layer: TileMapLayer 
@export var highlight_layer: TileMapLayer
@export var highlight_source_id: int = 0
@export var highlight_atlas_coords: Vector2i = Vector2i.ZERO

# Для hover эффекта
@export var hover_highlight_layer: TileMapLayer
@export var hover_source_id: int = 0
@export var hover_atlas_coords: Vector2i = Vector2i.ZERO
@export var base_scale: Vector2 = Vector2(1, 1)
@export var hover_scale: Vector2 = Vector2(1.3, 1.3)

var target_position: Vector2 = Vector2.ZERO
var is_moving: bool = false
var current_tile: Vector2i
var hovered_tile: Vector2i = Vector2i(-1, -1)

const KNIGHT_OFFSETS = [
	Vector2i(1, 2), Vector2i(1, -2), Vector2i(-1, 2), Vector2i(-1, -2),
	Vector2i(2, 1), Vector2i(2, -1), Vector2i(-2, 1), Vector2i(-2, -1)
]

func _ready():
	if tile_map_layer:
		current_tile = get_tile_from_position(global_position)
		target_position = get_world_pos_from_tile(current_tile)
		global_position = target_position
		update_highlights()

func _unhandled_input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if is_moving or not tile_map_layer: return
		
		var mouse_world_pos = get_global_mouse_position()
		var clicked_tile = get_tile_from_position(mouse_world_pos)
		
		if not is_valid_ground(clicked_tile): return
		if not is_valid_knight_move(current_tile, clicked_tile): return
		
		clear_highlights()
		set_target(get_world_pos_from_tile(clicked_tile))

func is_valid_ground(tile: Vector2i) -> bool:
	return tile_map_layer.get_cell_source_id(tile) != -1

func get_tile_from_position(world_pos: Vector2) -> Vector2i:
	var base_size = tile_map_layer.tile_set.tile_size
	var scale_v = tile_map_layer.global_scale
	var eff_x = float(base_size.x) * scale_v.x
	var eff_y = float(base_size.y) * scale_v.y
	var local_x = world_pos.x - tile_map_layer.global_position.x
	var local_y = world_pos.y - tile_map_layer.global_position.y
	return Vector2i(int(local_x / eff_x), int(local_y / eff_y))

func get_world_pos_from_tile(tile: Vector2i) -> Vector2:
	var base_size = tile_map_layer.tile_set.tile_size
	var scale_v = tile_map_layer.global_scale
	var eff_x = float(base_size.x) * scale_v.x
	var eff_y = float(base_size.y) * scale_v.y
	var local_x = float(tile.x) * eff_x + eff_x / 2.0
	var local_y = float(tile.y) * eff_y + eff_y / 2.0
	return tile_map_layer.global_position + Vector2(local_x, local_y)

func is_valid_knight_move(from: Vector2i, to: Vector2i) -> bool:
	var dx = abs(to.x - from.x)
	var dy = abs(to.y - from.y)
	return (dx == 1 and dy == 2) or (dx == 2 and dy == 1)

func set_target(new_target: Vector2):
	target_position = new_target
	is_moving = true

func _physics_process(delta):
	if is_moving:
		var direction = target_position - global_position
		var distance = direction.length()
		
		if distance < speed * delta:
			global_position = target_position
			current_tile = get_tile_from_position(global_position)
			velocity = Vector2.ZERO
			is_moving = false
			update_highlights()
		else:
			velocity = direction.normalized() * speed
			move_and_slide()
	else:
		velocity = Vector2.ZERO
	
	# Обновляем hover эффект
	_update_hover_effect()

func update_highlights():
	if not highlight_layer or not tile_map_layer: return
	
	# Очищаем старые подсветки
	clear_highlights()
	
	# Ставим новые подсветки
	for offset in KNIGHT_OFFSETS:
		var target = current_tile + offset
		if is_valid_ground(target):
			highlight_layer.set_cell(target, highlight_source_id, highlight_atlas_coords)

func clear_highlights():
	if not highlight_layer: return
	
	for offset in KNIGHT_OFFSETS:
		var target = current_tile + offset
		highlight_layer.set_cell(target, -1)

# НОВЫЕ ФУНКЦИИ ДЛЯ HOVER ЭФФЕКТА
func _update_hover_effect():
	if not hover_highlight_layer or not tile_map_layer: return
	
	var mouse_world_pos = get_global_mouse_position()
	var mouse_tile = get_tile_from_position(mouse_world_pos)
	
	# Если курсор перешёл на другую клетку
	if mouse_tile != hovered_tile:
		# Очищаем старую hover подсветку
		if hovered_tile != Vector2i(-1, -1):
			hover_highlight_layer.set_cell(hovered_tile, -1)
		
		hovered_tile = mouse_tile
		
		# Проверяем, что курсор над валидной клеткой
		if is_valid_ground(hovered_tile):
			# Ставим hover подсветку в КЛЕТКУ сетки
			hover_highlight_layer.set_cell(hovered_tile, hover_source_id, hover_atlas_coords)
		else:
			# Если клетка невалидная, очищаем
			hovered_tile = Vector2i(-1, -1)

func _exit_tree():
	# Очищаем hover при выходе
	if hover_highlight_layer and hovered_tile != Vector2i(-1, -1):
		hover_highlight_layer.set_cell(hovered_tile, -1)
