extends CharacterBody2D

@export var speed: float = 400.0
@export var tile_map_layer: TileMapLayer 

var target_position: Vector2 = Vector2.ZERO
var is_moving: bool = false
var current_tile: Vector2i

func _ready():
	if tile_map_layer:
		current_tile = get_tile_from_position(global_position)
		target_position = get_world_pos_from_tile(current_tile)
		global_position = target_position

func _unhandled_input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if is_moving or not tile_map_layer: return
		
		var mouse_world_pos = get_global_mouse_position()
		var clicked_tile = get_tile_from_position(mouse_world_pos)
		
		# 1. Проверяем, существует ли там тайл (не пустая ли клетка)
		if not is_valid_ground(clicked_tile):
			return
			
		# 2. Проверяем, соответствует ли ход правилам коня (буквой Г)
		if not is_valid_knight_move(current_tile, clicked_tile): 
			return
		
		set_target(get_world_pos_from_tile(clicked_tile))

# НОВАЯ ФУНКЦИЯ: Проверка, нарисован ли тайл в этой клетке
func is_valid_ground(tile: Vector2i) -> bool:
	# get_cell_source_id возвращает ID тайла. Если клетка пустая, возвращает -1
	return tile_map_layer.get_cell_source_id(tile) != -1

func get_tile_from_position(world_pos: Vector2) -> Vector2i:
	var base_size = tile_map_layer.tile_set.tile_size
	var scale_v = tile_map_layer.global_scale
	
	var eff_x = float(base_size.x) * scale_v.x
	var eff_y = float(base_size.y) * scale_v.y
	
	var local_x = world_pos.x - tile_map_layer.global_position.x
	var local_y = world_pos.y - tile_map_layer.global_position.y
	
	var tile_x = int(local_x / eff_x)
	var tile_y = int(local_y / eff_y)
	
	return Vector2i(tile_x, tile_y)

func get_world_pos_from_tile(tile: Vector2i) -> Vector2:
	var base_size = tile_map_layer.tile_set.tile_size
	var scale_v = tile_map_layer.global_scale
	
	var eff_x = float(base_size.x) * scale_v.x
	var eff_y = float(base_size.y) * scale_v.y
	
	var local_x = float(tile.x) * eff_x + eff_x / 2.0
	var local_y = float(tile.y) * eff_y + eff_y / 2.0
	
	var world_x = tile_map_layer.global_position.x + local_x
	var world_y = tile_map_layer.global_position.y + local_y
	
	return Vector2(world_x, world_y)

func is_valid_knight_move(from: Vector2i, to: Vector2i) -> bool:
	var dx = abs(to.x - from.x)
	var dy = abs(to.y - from.y)
	return (dx == 1 and dy == 2) or (dx == 2 and dy == 1)

func set_target(new_target: Vector2):
	target_position = new_target
	is_moving = true

func _physics_process(delta):
	if is_moving:
		var direction = target_position - global_position
		var distance = direction.length()
		
		if distance < speed * delta:
			global_position = target_position
			current_tile = get_tile_from_position(global_position)
			velocity = Vector2.ZERO
			is_moving = false
		else:
			velocity = direction.normalized() * speed
			move_and_slide()
	else:
		velocity = Vector2.ZERO
